import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import os
import time

here_all = ["data1_1824", "data2_1824", "data1_1925", "data2_1925"] 
for here in here_all:
    data = here.rsplit("_", 1)[0] 
    data_name = here.split("_")[0]

    folder_path = f'./market_cap/{here}' 
    files = os.listdir(folder_path) 
    test_data_csv_files = [file for file in files if file.startswith(f'test_{data}') and file.endswith('.csv')]
    test_index_data_csv_files = [file for file in files if file.startswith(f'test_index_{data}') and file.endswith('.csv')]

    # PMOdrl
    folder_path_PMOdrl = f'./result_data/{here}/PMOdrl' 
    files_PMOdrl = os.listdir(folder_path_PMOdrl) 
    test_data_csv_files_PMOdrl = [file for file in files_PMOdrl if file.startswith(f'test_{data}') and file.endswith('.csv')]

    # ddpg
    folder_path_ddpg = f'./result_data/{here}/ddpg' 
    files_ddpg = os.listdir(folder_path_ddpg) 
    test_data_csv_files_ddpg = [file for file in files_ddpg if file.startswith(f'test_{data}') and file.endswith('.csv')]

    # sac
    folder_path_sac = f'./result_data/{here}/sac' 
    files_sac = os.listdir(folder_path_sac) 
    test_data_csv_files_sac = [file for file in files_sac if file.startswith(f'test_{data}') and file.endswith('.csv')]

    # td3
    folder_path_td3 = f'./result_data/{here}/td3' 
    files_td3 = os.listdir(folder_path_td3) 
    test_data_csv_files_td3 = [file for file in files_td3 if file.startswith(f'test_{data}') and file.endswith('.csv')]

    # Dddpg
    folder_path_Dddpg = f'./result_data/{here}/Dddpg' 
    files_Dddpg = os.listdir(folder_path_Dddpg) 
    test_data_csv_files_Dddpg = [file for file in files_Dddpg if file.startswith(f'test_{data}') and file.endswith('.csv')]

    # Hddpg
    folder_path_Hddpg = f'./result_data/{here}/Hddpg' 
    files_Hddpg = os.listdir(folder_path_Hddpg) 
    test_data_csv_files_Hddpg = [file for file in files_Hddpg if file.startswith(f'test_{data}') and file.endswith('.csv')]

    # MoED
    folder_path_MoED = f'./result_data/{here}/MoED' 
    files_MoED = os.listdir(folder_path_MoED) 
    test_data_csv_files_MoED = [file for file in files_MoED if file.startswith(f'test_{data}') and file.endswith('.csv')]


    def evaluate_portfolio(
        cumulative_returns,
        risk_free_rate=0,
        benchmark_cumulative=None,
        freq=252
        ):

        cumulative_returns = np.asarray(cumulative_returns)
        if benchmark_cumulative is not None:
            benchmark_cumulative = np.asarray(benchmark_cumulative)

        last_cumulative_returns = np.insert(cumulative_returns, 0, 1)
        last_cumulative_returns = np.asarray(last_cumulative_returns)
        daily_returns = np.diff(cumulative_returns, prepend=1) / last_cumulative_returns[:-1] 

        total_return = cumulative_returns[-1] / 1 - 1

        annualized_return = (1 + total_return) ** (freq / len(daily_returns)) - 1

        annualized_volatility = np.std(daily_returns) * np.sqrt(freq)

        downside_returns = daily_returns[daily_returns < 0]
        downside_volatility = np.std(downside_returns) * np.sqrt(freq) if len(downside_returns) > 0 else np.nan

        excess_daily_returns = daily_returns - 0 / freq
        sharpe_ratio = np.mean(excess_daily_returns) / np.std(daily_returns) * np.sqrt(freq) if np.std(daily_returns) > 0 else np.nan

        sortino_ratio = np.mean(excess_daily_returns) / downside_volatility * freq if downside_volatility > 0 else np.nan

        peak = 1.0  
        max_drawdown = 0.0
        
        for r in cumulative_returns:
            nav = r          
            if nav > peak:
                peak = nav       
            else:
                drawdown = (peak - nav) / peak
                if drawdown > max_drawdown:
                    max_drawdown = drawdown

        calmar_ratio = annualized_return / abs(max_drawdown) if max_drawdown != 0 else (cumulative_returns[-1] - cumulative_returns[0])

        if benchmark_cumulative is not None and len(benchmark_cumulative) == len(cumulative_returns):
            benchmark_returns = np.diff(benchmark_cumulative, prepend=1) / np.insert(benchmark_cumulative, 0, 1)[:-1]
            relative_returns = daily_returns - benchmark_returns
            tracking_error = np.std(relative_returns) * np.sqrt(freq)
            annualized_excess_return = (1 + np.mean(daily_returns)) ** freq - (1 + np.mean(benchmark_returns)) ** freq
            information_ratio = annualized_excess_return / tracking_error if tracking_error > 0 else np.nan
        else:
            information_ratio = np.nan

        return {
            "Annualized Return": annualized_return,
            "Cumulative Return": total_return,
            "Max Drawdown": max_drawdown,
            "Sharpe Ratio": sharpe_ratio,
            "Sortino Ratio": sortino_ratio,
            "Calmar Ratio": calmar_ratio,
            "Information Ratio": information_ratio
        }


    def test_data(): 
        market_weight = pd.read_csv(f'./market_cap/{here}/{test_data_csv_files[0]}')
        market_weight = market_weight.iloc[0,:] / 1e6
        start_time = market_weight.index[0]
        end_time = market_weight.index[-1]
        market_weight = market_weight.values
        print(f"market_weight: {len(market_weight)}")

        stock_index = pd.read_csv(f'./market_cap/{here}/{test_index_data_csv_files[0]}')
        stock_index = stock_index.iloc[0,:] / stock_index.iloc[0,0]
        stock_index = stock_index.values
        print(f"stock_index: {len(stock_index)}")

        if here[-4:] == '1925':
            bond = pd.read_csv(f'./data/{here}/bond_{data}_1.csv')
        elif here[-4:] == '1824':
            bond = pd.read_csv(f'./data/{here}/bond_{data}0_1.csv')
        
        bond['Date'] = pd.to_datetime(bond['Date']) 
        df_bond = bond.query("Date >= @start_time and Date <= @end_time")
        df_bond = df_bond.iloc[:,-1].values / 100

        number_test = len(test_data_csv_files_PMOdrl)
        first_csv = pd.read_csv(f'{folder_path_PMOdrl}/{test_data_csv_files_PMOdrl[0]}')
        columns = first_csv.columns

        # market_weight\PMOdrl\ddpg\sac\td3\Dddpg\Hddpg\MoED
        result_market_weight = pd.DataFrame(columns=columns)
        result_PMOdrl = pd.DataFrame(columns=columns)
        result_ddpg = pd.DataFrame(columns=columns)
        result_sac = pd.DataFrame(columns=columns)
        result_td3 = pd.DataFrame(columns=columns)
        result_Dddpg = pd.DataFrame(columns=columns)
        result_Hddpg = pd.DataFrame(columns=columns)
        result_MoED = pd.DataFrame(columns=columns)

        number_test_market_weight = len(test_data_csv_files)
        number_test_PMOdrl = len(test_data_csv_files_PMOdrl)
        number_test_ddpg = len(test_data_csv_files_ddpg)
        number_test_sac = len(test_data_csv_files_sac)
        number_test_td3 = len(test_data_csv_files_td3)
        number_test_Dddpg = len(test_data_csv_files_Dddpg)
        number_test_Hddpg = len(test_data_csv_files_Hddpg)
        number_test_MoED = len(test_data_csv_files_MoED)

        for each_test in range(number_test_market_weight):
            result_market_weight_temp = pd.read_csv(f'{folder_path}/{test_data_csv_files[each_test]}').iloc[-1,:]
            result_market_weight_temp.index = result_ddpg.columns
            result_market_weight = pd.concat([result_PMOdrl, result_market_weight_temp.to_frame().T], ignore_index=True)

        
        for each_test in range(number_test_PMOdrl):
            result_PMOdrl_temp = pd.read_csv(f'{folder_path_PMOdrl}/{test_data_csv_files_PMOdrl[each_test]}').iloc[-1,:]
            result_PMOdrl_temp.index = result_ddpg.columns
            result_PMOdrl = pd.concat([result_PMOdrl, result_PMOdrl_temp.to_frame().T], ignore_index=True)

        for each_test in range(number_test_ddpg):
            result_ddpg_temp = pd.read_csv(f'{folder_path_ddpg}/{test_data_csv_files_ddpg[each_test]}').iloc[-1,:]
            result_ddpg_temp.index = result_ddpg.columns
            result_ddpg = pd.concat([result_ddpg, result_ddpg_temp.to_frame().T], ignore_index=True)
            

        for each_test in range(number_test_sac):
            result_sac_temp = pd.read_csv(f'{folder_path_sac}/{test_data_csv_files_sac[each_test]}').iloc[-1,:]
            result_sac_temp.index = result_ddpg.columns
            result_sac = pd.concat([result_sac, result_sac_temp.to_frame().T], ignore_index=True)
            

        for each_test in range(number_test_td3):
            result_td3_temp = pd.read_csv(f'{folder_path_td3}/{test_data_csv_files_td3[each_test]}').iloc[-1,:]
            result_td3_temp.index = result_ddpg.columns
            result_td3 = pd.concat([result_td3, result_td3_temp.to_frame().T], ignore_index=True)
            

        for each_test in range(number_test_Dddpg):
            result_Dddpg_temp = pd.read_csv(f'{folder_path_Dddpg}/{test_data_csv_files_Dddpg[each_test]}').iloc[-1,:]
            result_Dddpg_temp.index = result_ddpg.columns
            result_Dddpg = pd.concat([result_Dddpg, result_Dddpg_temp.to_frame().T], ignore_index=True)
            

        for each_test in range(number_test_Hddpg):
            result_Hddpg_temp = pd.read_csv(f'{folder_path_Hddpg}/{test_data_csv_files_Hddpg[each_test]}').iloc[-1,:]
            result_Hddpg_temp.index = result_ddpg.columns
            result_Hddpg = pd.concat([result_Hddpg, result_Hddpg_temp.to_frame().T], ignore_index=True)
            

        for each_test in range(number_test_MoED):
            result_MoED_temp = pd.read_csv(f'{folder_path_MoED}/{test_data_csv_files_MoED[each_test]}').iloc[-1,:]
            result_MoED_temp.index = result_ddpg.columns
            result_MoED = pd.concat([result_MoED, result_MoED_temp.to_frame().T], ignore_index=True) 

        market_weight_average = result_market_weight.mean() / 1e6
        PMOdrl_average = result_PMOdrl.mean() / 1e6
        ddpg_average = result_ddpg.mean() / 1e6
        sac_average = result_sac.mean() / 1e6
        td3_average = result_td3.mean() / 1e6
        Dddpg_average = result_Dddpg.mean() / 1e6
        Hddpg_average = result_Hddpg.mean() 
        MoED_average = result_MoED.mean() / 1e6

        result_market_weight = market_weight_average.values
        result_PMOdrl = PMOdrl_average.values
        result_ddpg = ddpg_average.values
        result_sac = sac_average.values
        result_td3 = td3_average.values
        result_Dddpg = Dddpg_average.values
        result_Hddpg = Hddpg_average.values
        result_MoED = MoED_average.values

        print(f"result_market_weight: {len(result_market_weight)}")
        print(f"result_PMOdrl: {len(result_PMOdrl)}")
        print(f"result_ddpg: {len(result_ddpg)}")
        print(f"result_sac: {len(result_sac)}")
        print(f"result_td3: {len(result_td3)}")
        print(f"result_Dddpg: {len(result_Dddpg)}")
        print(f"result_Hddpg: {len(result_Hddpg)}")
        print(f"result_MoED: {len(result_MoED)}")


        x = pd.date_range(start=start_time, periods=(len(result_ddpg)), freq='B')
        title = here

        return (x, result_market_weight, stock_index, result_PMOdrl, 
                result_ddpg, result_sac, result_td3, 
                result_Dddpg, result_Hddpg, result_MoED, 
                df_bond, title)



    def tableAPI(model):

        # Define the horizontal coordinate and the vertical coordinate.
        columns = ["Annualized Return", "Cumulative Return", "Max Drawdown", "Sharpe Ratio", "Sortino Ratio", "Calmar Ratio", "Information Ratio"]
        index = ["PMOdrl(ours)", "stock_index", "market_weight", "ddpg", "sac", "td3", "Dddpg", "Hddpg", "MoED"]

        df = pd.DataFrame(columns=columns, index=index)

        (x, market_weight, stock_index, result_PMOdrl, 
                result_ddpg, result_sac, result_td3, 
                result_Dddpg, result_Hddpg, result_MoED, 
                df_bond, title) = model()
        temp_name = [result_PMOdrl, stock_index, market_weight, result_ddpg, result_sac, result_td3, result_Dddpg, result_Hddpg, result_MoED]
        
        for each, name in zip(temp_name,index):
            temp = evaluate_portfolio(each, df_bond, stock_index) 
            for column in columns:
                df.at[name, column] = temp[column]

        current_path = os.path.dirname(os.path.realpath(__file__))  
        model_dir = os.path.join(current_path, f'result_evaluate/{here}')
        model_name = model.__name__
        df.to_csv(os.path.join(model_dir, f"evaluate_table_{here}.csv"), index=True)


    if __name__ == '__main__':
        tableAPI(test_data)