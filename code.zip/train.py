import gym
import torch.nn as nn
import numpy as np
import pandas as pd
import random
import os
os.environ['CUDA_VISIBLE_DEVICES']='0'

import torch
import time
import copy
from agent import PMOdrlAgent
from OTHER import *
from Env import StockTradingEnv


class Args:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    lr_actor = 1e-5
    lr_critic1 =  1 * lr_actor
    lr_critic2 = 5 * lr_critic1
    theta = 0.95
    tau = 0.01
    ou_sigma = 0.5 
    ou_theta = 0.05 
    reward2_bigger = 1

    ou_eta_start = 0.4 
    ou_eta_end = 0.02
    eta_ratio = 0.8

    data_name = f'data5_1'
    data_year = f'data5_1925'
    
    memory_size = 10000
    batch_size = 64 
    ratio = 5/6
    train_EPISODE = 100
    test_EPISODE = 3
    window_size = 10
    gamma = 0.99



def main_function(df_features0, bond, name,calculate_price): 
    length_data = len(df_features0) 
    initial_amount = 1e6
    args = Args()
    gamma = Args.gamma
    batch = Args.batch_size
    theta = Args.theta
    window_size = Args.window_size

    window_size_start = 0
    window_size_end = window_size_start + NUM_STEP + window_size 

    df_features = df_features0.iloc[window_size_start:window_size_end,:]
    df_bond = bond.iloc[window_size_start:window_size_end,:]
    env = StockTradingEnv(df_features, df_bond, initial_amount=1e6, buy_cost_pct=0.00025, sell_cost_pct=0.00025, gamma=gamma, window_size = window_size)
    STATE_DIM, ACTION_DIM = env.state_and_action_dim()

    agent = PMOdrlAgent(STATE_DIM, ACTION_DIM, args)

    initial_share = np.zeros(ACTION_DIM-1, dtype=np.float32).reshape(-1, 1)
    initial_last_action = np.zeros(ACTION_DIM)
    initial_last_action[-1] = 1
    initial_episode_portfolio_value = initial_amount
    ou_noise = OUNoise(size=ACTION_DIM, theta=Args.ou_theta, sigma=Args.ou_sigma)

    REWARD_BUFFER_episode_portfolio_value = np.empty(shape=(NUM_EPISODE, length_data - window_size )) 
    REWARD_BUFFER_each_reward1 = np.empty(shape=(NUM_EPISODE, length_data  - window_size ))
    REWARD_BUFFER_each_reward2 = np.empty(shape=(NUM_EPISODE, length_data  - window_size ))
    REWARD_BUFFER_episode_reward1 = np.empty(shape=(NUM_EPISODE, length_data  - window_size ))
    REWARD_BUFFER_episode_reward2 = np.empty(shape=(NUM_EPISODE, length_data  - window_size ))
    REWARD_BUFFER_action = np.empty(shape=(NUM_EPISODE, (length_data  - window_size) * ACTION_DIM ))
    REWARD_BUFFER_actor_loss = np.empty(shape=(NUM_EPISODE))

    
    
    while window_size_start <= length_data - NUM_STEP - window_size:
        window_size_end = window_size_start + NUM_STEP + window_size 

        df_features = df_features0.iloc[window_size_start:window_size_end,:] 
        df_bond = bond.iloc[window_size_start:window_size_end,:]
        env = StockTradingEnv(df_features, df_bond, initial_amount=initial_amount, buy_cost_pct=0.00025, sell_cost_pct=0.00025, gamma=gamma, window_size = window_size,
                              shares=initial_share, last_action=initial_last_action)

        episode_M = -1
        while episode_M < NUM_EPISODE - 1:
            episode_M += 1

            state = env.reset() 
            episode_reward1 = 0
            episode_reward2 = 0
            episode_portfolio_value = initial_episode_portfolio_value

            last_action = initial_last_action

            for step_i in range(NUM_STEP):

                eta = get_eta_linear(
                    step=episode_M * NUM_STEP + step_i,
                    max_step=int(Args.eta_ratio * NUM_EPISODE * length_data),
                    eta_start=Args.ou_eta_start, eta_end=Args.ou_eta_end
                )

                action = agent.get_action(state) + eta * ou_noise.sample()
                action = np.clip(action, 0, None)
                action = action / (np.sum(action) + 1e-8)
                action_temp = action

                next_state, reward1, reward2, done, now_action, portfolio_value, last_amount, last_shares, total_asset = env.step(action, last_action, Args.reward2_bigger, calculate_price=calculate_price)

                episode_reward2 += gamma ** (NUM_STEP - step_i - 1) * reward2
                episode_portfolio_value *= portfolio_value
                reward = reward1 / (reward2 + 1e-4)
                episode_reward1 += gamma ** (NUM_STEP - step_i - 1) * reward

                REWARD_BUFFER_episode_portfolio_value[episode_M, window_size_start+step_i] = episode_portfolio_value.item()
                REWARD_BUFFER_each_reward1[episode_M, window_size_start + step_i] = reward   
                REWARD_BUFFER_each_reward2[episode_M, window_size_start + step_i] = reward2
                REWARD_BUFFER_episode_reward1[episode_M, window_size_start + step_i] = episode_reward1
                REWARD_BUFFER_episode_reward2[episode_M, window_size_start + step_i] = episode_reward2
                REWARD_BUFFER_action[episode_M, (window_size_start + step_i) * ACTION_DIM: (window_size_start + step_i + 1) * ACTION_DIM] = action_temp

                if done:
                    break
                
                agent.replay_buffer.add_memo(state, now_action, reward1, reward2, next_state, done) 

                state = next_state
                last_action = now_action
                agent.update(batch, theta) 

            
            REWARD_BUFFER_actor_loss[episode_M] = agent.actor_loss_history


        window_size_start += NUM_STEP

    env.close()


    current_path = os.path.dirname(os.path.realpath(__file__))                                                                  
    model_dir = os.path.join(current_path, 'models')
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)

    actor_model_path = os.path.join(model_dir, f"{name}_actor.pth")
    critic1_model_path = os.path.join(model_dir, f"{name}_critic1.pth")
    critic2_model_path = os.path.join(model_dir, f"{name}_critic2.pth")
    actor_optimizer_path = os.path.join(model_dir, f"{name}_actor_optimizer.pth")
    critic1_optimizer_path = os.path.join(model_dir, f"{name}_critic1_optimizer.pth")
    critic2_optimizer_path = os.path.join(model_dir, f"{name}_critic2_optimizer.pth")

    torch.save(agent.actor.state_dict(), actor_model_path)
    torch.save(agent.critic1.state_dict(), critic1_model_path)
    torch.save(agent.critic2.state_dict(), critic2_model_path)
    torch.save(agent.actor_optimizer.state_dict(), actor_optimizer_path)
    torch.save(agent.critic1_optimizer.state_dict(), critic1_optimizer_path)
    torch.save(agent.critic2_optimizer.state_dict(), critic2_optimizer_path)

    episode_portfolio_value_df = pd.DataFrame(REWARD_BUFFER_episode_portfolio_value)  
    dates = pd.date_range(start=start_date, periods=len(episode_portfolio_value_df.columns), freq='B')    
    date_str_list = dates.strftime('%Y-%m-%d').tolist() 
    episode_portfolio_value_df.columns = date_str_list 
    episode_portfolio_value_df.to_csv(os.path.join(model_dir, f"{name}_episode_portfolio_value.csv"), index=False)

    each_reward1_df = pd.DataFrame(REWARD_BUFFER_each_reward1)
    each_reward1_df.to_csv(os.path.join(model_dir, f"{name}_each_reward1.csv"), index=False)

    each_reward2_df = pd.DataFrame(REWARD_BUFFER_each_reward2)
    each_reward2_df.to_csv(os.path.join(model_dir, f"{name}_each_reward2.csv"), index=False)

    episode_reward1_df = pd.DataFrame(REWARD_BUFFER_episode_reward1)
    episode_reward1_df.to_csv(os.path.join(model_dir, f"{name}_episode_reward1.csv"), index=False)

    episode_reward2_df = pd.DataFrame(REWARD_BUFFER_episode_reward2)
    episode_reward2_df.to_csv(os.path.join(model_dir, f"{name}_episode_reward2.csv"), index=False)

    action_df = pd.DataFrame(REWARD_BUFFER_action)
    action_df.to_csv(os.path.join(model_dir, f"{name}_action.csv"), index=False)

    actor_loss_df = pd.DataFrame(REWARD_BUFFER_actor_loss, columns=['actor_loss'])
    actor_loss_df.to_csv(os.path.join(model_dir, f"{name}_actor_loss.csv"), index=False)

    return actor_model_path

def test(actor_model_path, df_features0, bond, name, calculate_price):
    device = Args.device
    print(device)
    actor_path = actor_model_path

    class AddNorm(nn.Module):
        def __init__(self, normalized_shape, dropout=0.0):
            super(AddNorm, self).__init__()
            self.layer_norm = nn.LayerNorm(normalized_shape)
            self.dropout = nn.Dropout(dropout)
        def forward(self, x, sublayer_output):
            return self.layer_norm(x + self.dropout(sublayer_output))
        
    class Actor(nn.Module): 
        def __init__(self, state_dim, action_dim, hidden_dim=64):
            super(Actor, self).__init__()               
            self.fc1 = nn.Linear(state_dim, hidden_dim) 
            self.fc2 = nn.Linear(hidden_dim, hidden_dim) 
            self.fc3 = nn.Linear(hidden_dim, hidden_dim) 
            self.fc4 = nn.Linear(hidden_dim, hidden_dim) 
            self.fc5 = nn.Linear(hidden_dim, action_dim)
            self.addnorm1 = AddNorm(hidden_dim)
            self.addnorm2 = AddNorm(hidden_dim)
            self.addnorm3 = AddNorm(hidden_dim)

        def forward(self, x):                       
            x = torch.relu(self.fc1(x))           
            x = self.addnorm1(x, torch.relu(self.fc2(x)))
            x = self.addnorm2(x, torch.relu(self.fc3(x)))
            x = self.addnorm3(x, torch.relu(self.fc4(x)))
            x = torch.softmax(self.fc5(x), dim=1)      
            return x

    length_data = len(df_features0)
    initial_amount = 1e6
    gamma = Args.gamma
    args = Args()
    device = Args.device
    
    window_size_start = 0
    window_size_end = window_size_start + NUM_STEP + window_size  

    df_features = df_features0.iloc[window_size_start:window_size_end,:]
    df_bond = bond.iloc[window_size_start:window_size_end,:]
    env = StockTradingEnv(df_features, df_bond, initial_amount=initial_amount, buy_cost_pct=0.00025, sell_cost_pct=0.00025, gamma=gamma, window_size = window_size)
    STATE_DIM, ACTION_DIM = env.state_and_action_dim()
    initial_share = np.zeros(ACTION_DIM-1, dtype=np.float32).reshape(-1, 1)
    initial_last_action = np.zeros(ACTION_DIM)
    initial_last_action[-1] = 1
    initial_episode_portfolio_value = initial_amount

    actor = Actor(STATE_DIM, ACTION_DIM).to(device)
    actor.load_state_dict(torch.load(actor_path, map_location=torch.device('cpu')))

    REWARD_BUFFER_episode_portfolio_value = np.empty(shape=(NUM_EPISODE, length_data - window_size ))
    REWARD_BUFFER_each_reward1 = np.empty(shape=(NUM_EPISODE, length_data  - window_size ))
    REWARD_BUFFER_each_reward2 = np.empty(shape=(NUM_EPISODE, length_data  - window_size ))
    REWARD_BUFFER_episode_reward1 = np.empty(shape=(NUM_EPISODE, length_data  - window_size ))
    REWARD_BUFFER_episode_reward2 = np.empty(shape=(NUM_EPISODE, length_data  - window_size ))
    REWARD_BUFFER_action = np.empty(shape=(NUM_EPISODE, (length_data  - window_size) * ACTION_DIM ))

    while window_size_start <= length_data - NUM_STEP - window_size:
        window_size_end = window_size_start + NUM_STEP + window_size 

        df_features = df_features0.iloc[window_size_start:window_size_end,:]
        df_bond = bond.iloc[window_size_start:window_size_end,:]
        env = StockTradingEnv(df_features, df_bond, initial_amount=initial_amount, buy_cost_pct=0.00025, sell_cost_pct=0.00025, gamma=gamma, window_size = window_size,
                            shares=initial_share, last_action=initial_last_action)

        episode_M = -1
        while episode_M < NUM_EPISODE - 1:
            episode_M += 1

            state = env.reset()
            episode_reward1 = 0
            episode_reward2 = 0
            episode_portfolio_value = initial_episode_portfolio_value

            last_action = np.zeros(ACTION_DIM)
            last_action[-1] = 1

            for step_i in range(NUM_STEP):
                state = np.squeeze(state)  
                state = torch.FloatTensor(state).unsqueeze(0).to(device) 
                action = actor(state)
                action = action.detach().cpu().numpy()[0]

                next_state, reward1, reward2, done, now_action, portfolio_value, last_amount, last_shares, total_asset = env.step(action, last_action,  reward2_bigger=Args.reward2_bigger, calculate_price=calculate_price)

                episode_reward1 += gamma ** (NUM_STEP - step_i - 1) * reward1  
                episode_reward2 += gamma ** (NUM_STEP - step_i - 1) * reward2
                print(f"Episode: {episode_M + 1}/{NUM_EPISODE}, time: {window_size_start + step_i + 1}/{length_data - window_size}, Reward:{round(episode_reward1,2)}")
                episode_portfolio_value *= portfolio_value

                REWARD_BUFFER_episode_portfolio_value[episode_M, window_size_start+step_i] = episode_portfolio_value
                REWARD_BUFFER_each_reward1[episode_M, window_size_start + step_i] = reward1   
                REWARD_BUFFER_each_reward2[episode_M, window_size_start + step_i] = reward2
                REWARD_BUFFER_episode_reward1[episode_M, window_size_start + step_i] = episode_reward1
                REWARD_BUFFER_episode_reward2[episode_M, window_size_start + step_i] = episode_reward2
                REWARD_BUFFER_action[episode_M, (window_size_start + step_i) * ACTION_DIM: (window_size_start + step_i + 1) * ACTION_DIM] = action
                
                state = next_state
                last_action = now_action

        window_size_start += NUM_STEP

        env.close()

        current_path = os.path.dirname(os.path.realpath(__file__))   
        model_dir = os.path.join(current_path, 'models')
        if not os.path.exists(model_dir): 
            os.makedirs(model_dir)

        episode_portfolio_value_df = pd.DataFrame(REWARD_BUFFER_episode_portfolio_value)
        dates = pd.date_range(start=start_date, periods=len(episode_portfolio_value_df.columns), freq='B') 
        date_str_list = dates.strftime('%Y-%m-%d').tolist()  
        episode_portfolio_value_df.columns = date_str_list 
        episode_portfolio_value_df.to_csv(os.path.join(model_dir, f"{name}_episode_portfolio_value.csv"), index=False)

        each_reward1_df = pd.DataFrame(REWARD_BUFFER_each_reward1)
        each_reward1_df.to_csv(os.path.join(model_dir, f"{name}_each_reward1.csv"), index=False)

        each_reward2_df = pd.DataFrame(REWARD_BUFFER_each_reward2)
        each_reward2_df.to_csv(os.path.join(model_dir, f"{name}_each_reward2.csv"), index=False)

        episode_reward1_df = pd.DataFrame(REWARD_BUFFER_episode_reward1)
        episode_reward1_df.to_csv(os.path.join(model_dir, f"{name}_episode_reward1.csv"), index=False)

        episode_reward2_df = pd.DataFrame(REWARD_BUFFER_episode_reward2)
        episode_reward2_df.to_csv(os.path.join(model_dir, f"{name}_episode_reward2.csv"), index=False)

        action_df = pd.DataFrame(REWARD_BUFFER_action)
        action_df.to_csv(os.path.join(model_dir, f"{name}_action.csv"), index=False)

if __name__ == '__main__':
    data_name = Args.data_name
    data_year = Args.data_year
    window_size = Args.window_size
    NUM_EPISODE = Args.train_EPISODE 
    ratio = Args.ratio 
    calculate_price = 'close' 
    
    data = pd.read_csv(f'./data/{data_year}/{data_name}.csv')
    bond = pd.read_csv(f'./data/{data_year}/bond_{data_name}.csv')
    
    length_data = len(data)
    start_date = data.iloc[window_size, 1]
    NUM_STEP = int(length_data*ratio) - window_size  

    df_features = data.iloc[:int(length_data*ratio),2:] 
    df_bond = bond.iloc[:int(length_data*ratio), 2:]

    train_name = f'train_{data_name}'
    actor_model_path = main_function(df_features, df_bond, train_name, calculate_price=calculate_price)

    test_name = f'test_{data_name}'
    NUM_EPISODE = Args.test_EPISODE
    end_length = int(length_data*ratio)
    NUM_STEP = length_data - end_length
    start_date = data.iloc[end_length , 1] 
    df_features = data.iloc[end_length - window_size :,2:] 
    df_bond = bond.iloc[end_length - window_size:, 2:]

    test(actor_model_path, df_features, df_bond, test_name, calculate_price=calculate_price)
