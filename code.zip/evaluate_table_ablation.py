import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import os
import time

here_all = ["data1_1824", "data2_1824", "data1_1925", "data2_1925"] 
for here in here_all:
    data = here.rsplit("_", 1)[0] 
    data_name = here.split("_")[0]

    folder_path = f'./market_cap/{here}' 
    files = os.listdir(folder_path) 
    test_data_csv_files = [file for file in files if file.startswith(f'test_{data}') and file.endswith('.csv')]
    test_index_data_csv_files = [file for file in files if file.startswith(f'test_index_{data}') and file.endswith('.csv')]

    # PMOdrl
    folder_path_PMOdrl = f'./result_data/{here}/PMOdrl' 
    files_PMOdrl = os.listdir(folder_path_PMOdrl) 
    test_data_csv_files_PMOdrl = [file for file in files_PMOdrl if file.startswith(f'test_{data}') and file.endswith('.csv')]

    # PMODRL_Pareto
    folder_path_PMODRL_Pareto = f'./result_data/{here}/PMODRL_Pareto' 
    files_PMODRL_Pareto = os.listdir(folder_path_PMODRL_Pareto) 
    test_data_csv_files_PMODRL_Pareto = [file for file in files_PMODRL_Pareto if file.startswith(f'test_{data}') and file.endswith('.csv')]

    # PMODRL_target
    folder_path_PMODRL_target = f'./result_data/{here}/PMODRL_target' 
    files_PMODRL_target = os.listdir(folder_path_PMODRL_target) 
    test_data_csv_files_PMODRL_target = [file for file in files_PMODRL_target if file.startswith(f'test_{data}') and file.endswith('.csv')]


    def evaluate_portfolio(
        cumulative_returns,
        risk_free_rate=0,
        benchmark_cumulative=None,
        freq=252
        ):

        cumulative_returns = np.asarray(cumulative_returns)
        if benchmark_cumulative is not None:
            benchmark_cumulative = np.asarray(benchmark_cumulative)

        last_cumulative_returns = np.insert(cumulative_returns, 0, 1)
        last_cumulative_returns = np.asarray(last_cumulative_returns)
        daily_returns = np.diff(cumulative_returns, prepend=1) / last_cumulative_returns[:-1] 

        total_return = cumulative_returns[-1] / 1 - 1

        annualized_return = (1 + total_return) ** (freq / len(daily_returns)) - 1

        annualized_volatility = np.std(daily_returns) * np.sqrt(freq)

        downside_returns = daily_returns[daily_returns < 0]
        downside_volatility = np.std(downside_returns) * np.sqrt(freq) if len(downside_returns) > 0 else np.nan

        excess_daily_returns = daily_returns - 0 / freq
        sharpe_ratio = np.mean(excess_daily_returns) / np.std(daily_returns) * np.sqrt(freq) if np.std(daily_returns) > 0 else np.nan

        sortino_ratio = np.mean(excess_daily_returns) / downside_volatility * freq if downside_volatility > 0 else np.nan

        peak = 1.0  
        max_drawdown = 0.0
        
        for r in cumulative_returns:
            nav = r         
            if nav > peak:
                peak = nav      
            else:
                drawdown = (peak - nav) / peak
                if drawdown > max_drawdown:
                    max_drawdown = drawdown

        calmar_ratio = annualized_return / abs(max_drawdown) if max_drawdown != 0 else (cumulative_returns[-1] - cumulative_returns[0])

        if benchmark_cumulative is not None and len(benchmark_cumulative) == len(cumulative_returns):
            benchmark_returns = np.diff(benchmark_cumulative, prepend=1) / np.insert(benchmark_cumulative, 0, 1)[:-1]
            relative_returns = daily_returns - benchmark_returns
            tracking_error = np.std(relative_returns) * np.sqrt(freq)
            annualized_excess_return = (1 + np.mean(daily_returns)) ** freq - (1 + np.mean(benchmark_returns)) ** freq
            information_ratio = annualized_excess_return / tracking_error if tracking_error > 0 else np.nan
        else:
            information_ratio = np.nan

        return {
            "Annualized Return": annualized_return,
            "Cumulative Return": total_return,
            "Max Drawdown": max_drawdown,
            "Sharpe Ratio": sharpe_ratio,
            "Sortino Ratio": sortino_ratio,
            "Calmar Ratio": calmar_ratio,
            "Information Ratio": information_ratio
        }


    def test_data(): 

        market_weight = pd.read_csv(f'./market_cap/{here}/{test_data_csv_files[0]}')
        market_weight = market_weight.iloc[0,:] / 1e6
        start_time = market_weight.index[0]
        end_time = market_weight.index[-1]
        market_weight = market_weight.values
        print(f"market_weight: {len(market_weight)}")

        stock_index = pd.read_csv(f'./market_cap/{here}/{test_index_data_csv_files[0]}')
        stock_index = stock_index.iloc[0,:] / stock_index.iloc[0,0]
        stock_index = stock_index.values
        print(f"stock_index: {len(stock_index)}")

        if here[-4:] == '1925':
            bond = pd.read_csv(f'./data/{here}/bond_{data}_1.csv')
        elif here[-4:] == '1824':
            bond = pd.read_csv(f'./data/{here}/bond_{data}0_1.csv')
        
        bond['Date'] = pd.to_datetime(bond['Date']) 
        df_bond = bond.query("Date >= @start_time and Date <= @end_time")
        df_bond = df_bond.iloc[:,-1].values / 100

        number_test = len(test_data_csv_files_PMOdrl)
        first_csv = pd.read_csv(f'{folder_path_PMOdrl}/{test_data_csv_files_PMOdrl[0]}')
        columns = first_csv.columns

        # market_weight\PMOdrl\ddpg\sac\td3\Dddpg\Hddpg\MoED
        result_market_weight = pd.DataFrame(columns=columns)
        result_PMOdrl = pd.DataFrame(columns=columns)
        result_PMODRL_Pareto = pd.DataFrame(columns=columns)
        result_PMODRL_target = pd.DataFrame(columns=columns)

        number_test_market_weight = len(test_data_csv_files)
        number_test_PMOdrl = len(test_data_csv_files_PMOdrl)
        number_test_PMODRL_Pareto = len(test_data_csv_files_PMODRL_Pareto)
        number_test_PMODRL_target = len(test_data_csv_files_PMODRL_target)

        for each_test in range(number_test_market_weight):
            result_market_weight_temp = pd.read_csv(f'{folder_path}/{test_data_csv_files[each_test]}').iloc[-1,:]
            result_market_weight_temp.index = result_PMODRL_Pareto.columns
            result_market_weight = pd.concat([result_PMOdrl, result_market_weight_temp.to_frame().T], ignore_index=True)

        
        for each_test in range(number_test_PMOdrl):
            result_PMOdrl_temp = pd.read_csv(f'{folder_path_PMOdrl}/{test_data_csv_files_PMOdrl[each_test]}').iloc[-1,:]
            result_PMOdrl_temp.index = result_PMODRL_Pareto.columns
            result_PMOdrl = pd.concat([result_PMOdrl, result_PMOdrl_temp.to_frame().T], ignore_index=True)

        for each_test in range(number_test_PMODRL_Pareto):
            result_PMODRL_Pareto_temp = pd.read_csv(f'{folder_path_PMODRL_Pareto}/{test_data_csv_files_PMODRL_Pareto[each_test]}').iloc[-1,:]
            result_PMODRL_Pareto_temp.index = result_PMODRL_Pareto.columns
            result_PMODRL_Pareto = pd.concat([result_PMODRL_Pareto, result_PMODRL_Pareto_temp.to_frame().T], ignore_index=True)
            

        for each_test in range(number_test_PMODRL_target):
            result_PMODRL_target_temp = pd.read_csv(f'{folder_path_PMODRL_target}/{test_data_csv_files_PMODRL_target[each_test]}').iloc[-1,:]
            result_PMODRL_target_temp.index = result_PMODRL_Pareto.columns
            result_PMODRL_target = pd.concat([result_PMODRL_target, result_PMODRL_target_temp.to_frame().T], ignore_index=True)

        market_weight_average = result_market_weight.mean() / 1e6
        PMOdrl_average = result_PMOdrl.mean() / 1e6
        PMODRL_Pareto_average = result_PMODRL_Pareto.mean() / 1e6
        PMODRL_target_average = result_PMODRL_target.mean() / 1e6

        result_market_weight = market_weight_average.values
        result_PMOdrl = PMOdrl_average.values
        result_PMODRL_Pareto = PMODRL_Pareto_average.values
        result_PMODRL_target = PMODRL_target_average.values

        print(f"result_market_weight: {len(result_market_weight)}")
        print(f"result_PMOdrl: {len(result_PMOdrl)}")
        print(f"result_ddpg: {len(result_PMODRL_Pareto)}")
        print(f"result_PMODRL_target: {len(result_PMODRL_target)}")

        x = pd.date_range(start=start_time, periods=(len(result_PMODRL_Pareto)), freq='B')
        title = here

        return (x, result_market_weight, stock_index, result_PMOdrl, 
                result_PMODRL_Pareto, result_PMODRL_target, 
                df_bond, title)



    def tableAPI(model):

        # Define the horizontal coordinate and the vertical coordinate.
        columns = ["Annualized Return", "Cumulative Return", "Max Drawdown", "Sharpe Ratio", "Sortino Ratio", "Calmar Ratio", "Information Ratio"]
        index = ["PMOdrl(ours)", "PMODRL_Pareto", "PMODRL_target"]

        df = pd.DataFrame(columns=columns, index=index)

        (x, result_market_weight, stock_index, result_PMOdrl, 
                result_PMODRL_Pareto, result_PMODRL_target, 
                df_bond, title) = model()
        temp_name = [result_PMOdrl, result_PMODRL_Pareto, result_PMODRL_target]
        
        for each, name in zip(temp_name,index):
            temp = evaluate_portfolio(each, df_bond, stock_index) 
            for column in columns:
                df.at[name, column] = temp[column]

        current_path = os.path.dirname(os.path.realpath(__file__)) 
        model_dir = os.path.join(current_path, f'result_evaluate/{here}')
        model_name = model.__name__
        df.to_csv(os.path.join(model_dir, f"evaluate_table_ablation_{here}.csv"), index=True)


    if __name__ == '__main__':
        tableAPI(test_data)