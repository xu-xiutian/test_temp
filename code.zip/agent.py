
import random
import logging
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque 
import torch.nn.init as init
import torch.nn.functional as F
import os
from datetime import datetime
from torch.utils.tensorboard import SummaryWriter
from OTHER import *

def pareto_dominated(q1, q2, q1_list, q2_list):
    for q1_other, q2_other in zip(q1_list, q2_list):
        if q1_other >= q1 and q2_other <= q2 and (q1_other > q1 or q2_other < q2):
            return True 
    return False

def get_pareto_q_values(q1_list, q2_list):
    pareto_q = []
    for q1, q2 in zip(q1_list, q2_list):
        if not pareto_dominated(q1, q2, q1_list, q2_list):
            pareto_q.append((q1, q2))
    return pareto_q


def find_max_sharpe_ratio(pareto_q, reward2_bigger):
    sharpe_ratios = []

    for (q1, q2) in pareto_q:
        sharpe_ratio =  (q1 ) / (q2/reward2_bigger + 1e-4) 
        sharpe_ratios.append(sharpe_ratio)

    sharpe_ratios_tensor = torch.stack(sharpe_ratios) 
    max_sharpe_ratio = torch.max(sharpe_ratios_tensor)

    max_sharpe_index = torch.argmax(sharpe_ratios_tensor) 
    (max_q1, max_q2) = pareto_q[max_sharpe_index] 

    return max_sharpe_ratio, (max_q1), max_q2/reward2_bigger

    

class Actor(nn.Module): 
    def __init__(self, state_dim, action_dim, hidden_dim=64):
        super(Actor, self).__init__()               
        self.fc1 = nn.Linear(state_dim, hidden_dim) 
        self.fc2 = nn.Linear(hidden_dim, hidden_dim) 
        self.fc3 = nn.Linear(hidden_dim, hidden_dim) 
        self.fc4 = nn.Linear(hidden_dim, hidden_dim) 
        self.fc5 = nn.Linear(hidden_dim, action_dim)
        self.addnorm1 = AddNorm(hidden_dim)
        self.addnorm2 = AddNorm(hidden_dim)
        self.addnorm3 = AddNorm(hidden_dim)

    def forward(self, x):                       
        x = torch.relu(self.fc1(x))           
        x = self.addnorm1(x, torch.relu(self.fc2(x)))
        x = self.addnorm2(x, torch.relu(self.fc3(x)))
        x = self.addnorm3(x, torch.relu(self.fc4(x)))
        x = torch.softmax(self.fc5(x), dim=1)    
        return x


class Critic1(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim=64):
        super(Critic1, self).__init__()
        self.fc1 = nn.Linear(state_dim+action_dim, hidden_dim)  
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, hidden_dim)
        self.fc4 = nn.Linear(hidden_dim, out_features=1)        
        self.addnorm1 = AddNorm(hidden_dim)
        self.addnorm2 = AddNorm(hidden_dim)

    def forward(self, x, a):
        x = torch.cat([x,a], dim=1)  
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = torch.relu(self.fc3(x))
        x = self.addnorm1(x, torch.relu(self.fc2(x)))
        x = self.addnorm2(x, torch.relu(self.fc3(x)))
        x = self.fc4(x) 
        return x
    
class Critic2(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim=64):
        super(Critic2, self).__init__()
        self.fc1 = nn.Linear(state_dim+action_dim, hidden_dim)  
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, hidden_dim)
        self.fc4 = nn.Linear(hidden_dim, out_features=1)        
        self.addnorm1 = AddNorm(hidden_dim)
        self.addnorm2 = AddNorm(hidden_dim)

    def forward(self, x, a):
        x = torch.cat([x,a], dim=1)  
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = torch.relu(self.fc3(x))
        x = self.addnorm1(x, torch.relu(self.fc2(x)))
        x = self.addnorm2(x, torch.relu(self.fc3(x)))
        x = self.fc4(x) 
        x = torch.relu(x)
        return x


class ReplayMemory:
    def __init__(self, capacity): 
        self.buffer = deque(maxlen=capacity) 

    def add_memo(self, state, now_action, reward1, reward2, next_state, done):  
        def reshape_state(state):
            if isinstance(state, pd.DataFrame):
                return state.values.reshape(1, -1)
            elif isinstance(state, np.ndarray):
                return state.reshape(1, -1)
    
        state = reshape_state(state) 
        now_action = np.expand_dims(now_action, 0) 
        next_state = np.expand_dims(next_state, 0) 
        self.buffer.appendleft((state, now_action, reward1, reward2, next_state, done)) 

    def sample(self, batch_size):
        state, action, reward1, reward2, next_state, done = zip(*random.sample(self.buffer, batch_size)) 
        return np.concatenate(state), np.concatenate(action), reward1, reward2, np.concatenate(next_state), done        
    
    def __len__(self):
        return len(self.buffer)
    
class PMOdrlAgent:
    def __init__(self, state_dim, action_dim, args):
        self.gamma = args.gamma 
        self.tau = args.tau 
        self.device = args.device
        self.reward2_bigger = args.reward2_bigger

        self.actor = Actor(state_dim, action_dim).to(self.device)
        self.actor_target = Actor(state_dim, action_dim).to(self.device)
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=args.lr_actor)

        self.critic1 = Critic1(state_dim, action_dim).to(self.device)
        self.critic2 = Critic2(state_dim, action_dim).to(self.device)
        self.critic1_target = Critic1(state_dim, action_dim).to(self.device)
        self.critic2_target = Critic2(state_dim, action_dim).to(self.device)
        self.critic1_target.load_state_dict(self.critic1.state_dict())
        self.critic2_target.load_state_dict(self.critic2.state_dict())

        self.critic1_optimizer = optim.Adam(self.critic1.parameters(), lr=args.lr_critic1, weight_decay=1e-4)
        self.critic2_optimizer = optim.Adam(self.critic2.parameters(), lr=args.lr_critic2, weight_decay=1e-4)


        self.replay_buffer = ReplayMemory(args.memory_size)

        self.Critic1_grad_norm = []
        self.Critic2_grad_norm = []
        self.Actor_grad_norm = []


    def _init_weights(self):
        for name, param in self.named_parameters():
            if 'weight' in name:  
                if param.dim() > 1:
                    nn.init.xavier_uniform_(param)  
            elif 'bias' in name:  
                nn.init.zeros_(param)  

    def get_action(self, state):
        state = np.squeeze(state)  
        state = torch.FloatTensor(state).unsqueeze(0).to(self.device) 
        action = self.actor(state)
        return action.detach().cpu().numpy()[0]
    
    def update(self, batch, theta=1):
        if len(self.replay_buffer) < batch:
            return                               
        
        states, now_actions, rewards1, rewards2, next_states, dones = self.replay_buffer.sample(batch)
        states = torch.FloatTensor(states).to(self.device)
        now_actions = torch.FloatTensor(now_actions).to(self.device)      
        rewards1 = torch.FloatTensor(np.array(rewards1)).unsqueeze(1).to(self.device)
        rewards2 = torch.FloatTensor(np.array(rewards2)).unsqueeze(1).to(self.device)
        next_states = torch.FloatTensor(next_states).to(self.device)
        dones = torch.FloatTensor(dones).unsqueeze(1).to(self.device)

        next_action = self.actor_target(next_states)

        target_q1 = self.critic1_target(next_states, next_action).detach()
        target_q2 = self.critic2_target(next_states, next_action).detach()      
        target_Q1 = (rewards1).clone().detach().float().cuda() + self.gamma * target_q1
        target_Q2 = (rewards2).clone().detach().float().cuda() + self.gamma * target_q2

        current_q1 = self.critic1(states, now_actions)
        current_q2 = self.critic2(states, now_actions)
        self.current_Q1 = current_q1
        self.current_Q2 = current_q2

        critic1_loss = nn.MSELoss()(current_q1, target_Q1 )  
        self.critic1_optimizer.zero_grad() 
        critic1_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic1.parameters(), max_norm=5) 
        self.critic1_optimizer.step()

        
        critic2_loss = nn.MSELoss()(current_q2, target_Q2)
        self.critic2_optimizer.zero_grad() 
        critic2_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic2.parameters(), max_norm=5)
        self.critic2_optimizer.step()

        self.critic1_loss_history = critic1_loss.item()
        self.critic2_loss_history = critic2_loss.item()
        self.current_Q1_history = self.current_Q1.mean().item()
        self.current_Q2_history = self.current_Q2.mean().item()

        actions = self.actor(states)
        
        q1 = self.critic1(states, actions)
        q2 = self.critic2(states, actions)
        pareto_q = get_pareto_q_values(q1,q2)
        self.max_sortino_ratio, self.max_q1, self.max_q2 = find_max_sharpe_ratio(pareto_q, self.reward2_bigger)
        actor_loss = - (theta * self.max_q1 - (1 - theta) * self.max_q2 ) 

        self.actor_optimizer.zero_grad() 
        actor_loss.backward()            
        self.actor_loss_history = actor_loss.item()
        self.actor_optimizer.step() 

        for param, target_param in zip(self.actor.parameters(), self.actor_target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

        for param, target_param in zip(self.critic1.parameters(), self.critic1_target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

        for param, target_param in zip(self.critic2.parameters(), self.critic2_target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)