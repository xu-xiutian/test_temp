import gym
import copy
import numpy as np
import pandas as pd
import numpy.random as rd
from gym import spaces

class StockTradingEnv(gym.Env):
    def __init__(self, df_features, bond, initial_amount=1e6, buy_cost_pct=0.00025, sell_cost_pct=0.00025, gamma=0.99, window_size = 10,
                 shares=None, last_action=0):
        self.window_size = window_size
        self.df_features = df_features
        self.bond = bond
        self.closing = self.df_features.filter(like='closing') 
        self.open = self.df_features.filter(like='Open') 
        self.n_stock = self.closing.shape[1]         
        self.dates = list(self.df_features.index)            
        self.index = 0 + self.window_size                             
        self.indicator = int(self.df_features.shape[1] / self.n_stock) 
        
        self.buy_cost_rate = buy_cost_pct       
        self.sell_cost_rate = sell_cost_pct
        self.initial_amount = initial_amount
        self.gamma = gamma                         

        self.REWARD = []
        self.total_asset = None
        self.cumulative_returns = 0    

        self.amount_dim = 1                 

        self.state_dim = (self.n_stock * self.indicator * self.window_size + self.window_size) 
        self.action_dim = self.n_stock + self.amount_dim
        self.max_step = len(self.closing)     

        self.initial_last_action = last_action
        self.amount = initial_amount 
        self.initial_shares = shares

    def state_and_action_dim(self):
        return self.state_dim, self.action_dim

    def reset(self):
        self.index = 0 + self.window_size - 1
        self.closing = self.df_features.filter(like='closing')
        self.open = self.df_features.filter(like='Open')
        if hasattr(self, 'now_action') and self.now_action is not None:
            self.last_action = self.now_action
        else:
            self.last_action = self.initial_last_action

        self.amount = copy.deepcopy(self.initial_amount) 
        self.shares = copy.deepcopy(self.initial_shares)

        self.REWARD = list()
        self.REWARD_close = list()
        self.total_asset = np.dot(self.closing.iloc[self.index], self.shares) + self.amount 
        return self.get_state()

    def get_state(self): 
        old_features = self.df_features.iloc[self.index-self.window_size + 1: self.index + 1]
        closing = old_features.filter(like='closing').values
        open = old_features.filter(like='Open').values
        high = old_features.filter(like='High').values
        low = old_features.filter(like='Low').values
        
        volume = old_features.filter(like='Volume')
        stds_volume = np.std(volume, axis=0) + 1e-3
        means_volume = np.mean(volume, axis=0)
        volume_standardized = (volume - means_volume) / stds_volume
        volume_standardized = volume_standardized.values

        old_bond = self.bond.iloc[self.index-self.window_size + 1: self.index + 1].values

        state = np.hstack((
                    (closing).flatten(),
                    (open).flatten(),
                    (high).flatten(),
                    (low).flatten(),
                    (volume_standardized).flatten(),
                    (old_bond ).flatten()
                    ))
        
        return state

    def step(self, action, last_action, reward2_bigger=1, calculate_price='close'):
        self.last_action = last_action
        action = copy.deepcopy(action)  

        if calculate_price == 'open_close':
            for i_stock in range(self.n_stock):
                stock_i_expect_number = int(action[i_stock] * self.total_asset / self.closing.iloc[self.index][i_stock]) 

                if self.shares[i_stock] >= stock_i_expect_number:                                    
                    stock_i_open = self.open.iloc[self.index+1][i_stock]                             
                    stock_i_sell_number = self.shares[i_stock] - stock_i_expect_number              
                    self.amount += stock_i_open * stock_i_sell_number * (1 - self.sell_cost_rate)   
                    self.shares[i_stock] = stock_i_expect_number

            for i_stock in range(self.n_stock):
                stock_i_expect_number = int(action[i_stock] * self.total_asset / self.closing.iloc[self.index][i_stock])
                if self.shares[i_stock] < stock_i_expect_number:                                                                                                                                                                       
                    stock_i_buy_expect_number = stock_i_expect_number - self.shares[i_stock]   
                    stock_i_closing = self.closing.iloc[self.index+1][i_stock]                                              
                    stock_i_buy_number = min(stock_i_buy_expect_number, int(self.amount / (stock_i_closing * (1 + self.buy_cost_rate))))                                    
                    cost_amount = stock_i_closing * stock_i_buy_number * (1 + self.buy_cost_rate)                                           
                    self.amount -= cost_amount                                  
                    self.shares[i_stock] += stock_i_buy_number                  

            total_asset = np.dot(self.closing.iloc[self.index+1], self.shares) + self.amount 
            last_total_asset = copy.deepcopy(self.total_asset)
            self.total_asset = copy.deepcopy(total_asset)  

            now_action = np.zeros(self.action_dim, dtype=np.float32)
            for i in range(self.n_stock):  
                now_action[i] = self.closing.iloc[self.index+1][i] * self.shares[i] / self.total_asset
            now_action[-1] = 1 - np.sum(now_action)
            self.now_action = now_action

        
        elif calculate_price == 'close':
            for i_stock in range(self.n_stock):
                stock_i_expect_number = int(action[i_stock] * self.total_asset / self.closing.iloc[self.index][i_stock]) 

                if self.shares[i_stock] >= stock_i_expect_number:                                                               
                    stock_i_closing = self.closing.iloc[self.index+1][i_stock] 
                    stock_i_sell_number = self.shares[i_stock] - stock_i_expect_number                          
                    self.amount += stock_i_closing * stock_i_sell_number * (1 - self.sell_cost_rate)   
                    self.shares[i_stock] = stock_i_expect_number

            for i_stock in range(self.n_stock):
                stock_i_expect_number = int(action[i_stock] * self.total_asset / self.closing.iloc[self.index][i_stock])
                if self.shares[i_stock] < stock_i_expect_number:                                                                                                                       
                    stock_i_buy_expect_number = stock_i_expect_number - self.shares[i_stock]   
                    stock_i_closing = self.closing.iloc[self.index+1][i_stock]                                              
                    stock_i_buy_number = min(stock_i_buy_expect_number, int(self.amount / (stock_i_closing * (1 + self.buy_cost_rate))))                                   
                    cost_amount = stock_i_closing * stock_i_buy_number * (1 + self.buy_cost_rate)                                            
                    self.amount -= cost_amount                                  
                    self.shares[i_stock] += stock_i_buy_number                  

            total_asset = np.dot(self.closing.iloc[self.index+1], self.shares) + self.amount  
            last_total_asset = copy.deepcopy(self.total_asset)
            self.total_asset = copy.deepcopy(total_asset)  

            now_action = np.zeros(self.action_dim, dtype=np.float32)
            for i in range(self.n_stock):  
                now_action[i] = self.closing.iloc[self.index+1][i] * self.shares[i] / self.total_asset
            now_action[-1] = 1 - np.sum(now_action)
            self.now_action = now_action


        elif calculate_price == 'open':
            for i_stock in range(self.n_stock):
                stock_i_expect_number = int(action[i_stock] * self.total_asset / self.open.iloc[self.index][i_stock]) 

                if self.shares[i_stock] >= stock_i_expect_number:                                   
                    stock_i_open = self.open.iloc[self.index+1][i_stock]                             
                    stock_i_sell_number = self.shares[i_stock] - stock_i_expect_number                         
                    self.amount += stock_i_open * stock_i_sell_number * (1 - self.sell_cost_rate)  
                    self.shares[i_stock] = stock_i_expect_number

            for i_stock in range(self.n_stock):
                stock_i_expect_number = int(action[i_stock] * self.total_asset / self.open.iloc[self.index][i_stock])
                if self.shares[i_stock] < stock_i_expect_number:                                                                                                                        
                    stock_i_buy_expect_number = stock_i_expect_number - self.shares[i_stock]   
                    stock_i_open = self.open.iloc[self.index+1][i_stock]
                    stock_i_buy_number = min(stock_i_buy_expect_number, int(self.amount / (stock_i_open * (1 + self.buy_cost_rate))))                                   
                    cost_amount = stock_i_open * stock_i_buy_number * (1 + self.buy_cost_rate)                                           
                    self.amount -= cost_amount                                  
                    self.shares[i_stock] += stock_i_buy_number                  

            total_asset = np.dot(self.open.iloc[self.index+1], self.shares) + self.amount  
            last_total_asset = copy.deepcopy(self.total_asset)
            self.total_asset = copy.deepcopy(total_asset)  

            now_action = np.zeros(self.action_dim, dtype=np.float32)
            for i in range(self.n_stock):  
                now_action[i] = self.open.iloc[self.index+1][i] * self.shares[i] / self.total_asset
            now_action[-1] = 1 - np.sum(now_action)
            self.now_action = now_action


        R_now = total_asset / last_total_asset - 1
        
        self.REWARD_close.append(R_now)

        Rf = self.bond.iloc[self.index+1,0] / 100
        Rf = Rf.round(4)
        T = self.bond.iloc[self.window_size-1:,0] / 100
        T = T.round(4)

        reward1 = (R_now.item() - Rf + 1) 

        if len(self.REWARD_close) == 1:  
            reward2 = 0
        else:
            reward2 = np.std(self.REWARD_close, ddof=1)

        reward2 *= reward2_bigger


        portfolio_value = R_now + 1

        self.index += 1
        done = (self.index == self.max_step - 1) 
        if done:
            state = {}
        else:
            state = self.get_state()


        return state, reward1, reward2, done, now_action, portfolio_value, self.amount, self.shares, self.total_asset

